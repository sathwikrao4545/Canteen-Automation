<html> 
    <head> 
        <title> User Login And Registration </title>  
        <link rel="stylesheet" type="text/css" href="style1.css">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="icon" type="image" href="https://www.bluehomepm.com/wp-content/uploads/2017/09/BlueHomePM-Favicon.png">
   
</head> 
<body> 


    <div class="container">  
        <div class="login-box">
        <div class="row"> 
            <div class="col-md-6 login-left"> 
                <h2> Login Here </h2> 
                <form action="validation.php" method="post"> 
                    <div class="form-group"> 
                        <label>Username</label> 
                        <input type="text" name="user" class="form-control" required > 
</div>  
<div class="form-group"> 
                        <label>Password</label> 
                        <input type="password" name="password" class="form-control" required > 
</div>  
<button type="submit" class="btn btn-primary"> LOGIN </button> 
</form> 
</div>  
</div>  
</div>
</div> 
</body> 
</html> 


